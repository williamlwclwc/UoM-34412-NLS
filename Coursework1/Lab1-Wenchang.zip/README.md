# How to run

## For task1

1. You might need to install NLTK package in advance
2. Simply using: "python task1.py" to run the script and see the result

## For task2

1. You might need to install NLTK, Scikit-Learn, Numpy in advance
2. You can already see the output results in the jupyter notebook, you can also rerun the cells but it might took a while
